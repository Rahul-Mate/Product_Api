﻿namespace ProductApis.Controllers
{
    using Domain.Models;
    using Microsoft.AspNetCore.Mvc;
    using Service.IService;
    using Swashbuckle.AspNetCore.Annotations;
    using System.Text.Json;

    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;
        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        // GET: api/Products
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>?>> GetAllActiveProducts()
        {
            return Ok((await _productService.GetAllActiveProducts())?.ToList());
        }

       
        [HttpGet("/search/{productName?}/{minPrice:decimal=null}/{maxPrice:decimal=null}/{minPostedDate:DateTime?}/{maxPostedDate:DateTime?}")]
        [SwaggerOperationFilter(typeof(ReApplyOptionalRouteParameterOperationFilter))]
        public async Task<ActionResult<IEnumerable<Product>?>> GetProducts(string? productName, decimal? minPrice, decimal? maxPrice ,
            DateTime? minPostedDate, DateTime? maxPostedDate)
        {
            return Ok((await _productService.SearchProducts(productName, minPrice, maxPrice, minPostedDate, maxPostedDate))?.ToList());
        }

        [HttpPost]
        public async Task<ActionResult> InsertProduct(Product product)
        {
            if (ModelState.IsValid && product.Price <= 10000)
            {
                await _productService.Insert(product);
                return Ok();
            }
            else
            {
                return BadRequest($"Invalid product data {JsonSerializer.Serialize(product)}, price must not exceed $10,000");
            }
        }

        [HttpPut]
        public async Task<ActionResult> UpdateProduct(Product product)
        {
            if (ModelState.IsValid && product.Id > 0)
            {
                await _productService.Update(product);
                return Ok();
            }
            else
            {
                return BadRequest($"Invalid product data {JsonSerializer.Serialize(product)}");
            }
        }

        [HttpDelete("{productId}")]
        public async Task<IActionResult> DeleteProduct(int productId)
        {
            await _productService.Delete(productId);
            return Ok();
        }

        [HttpGet("/approval-queue")]
        public async Task<IActionResult> GetApprovalQueueProducts()
        {
            return Ok(await _productService.GetAllPendingQueueProducts());
        }

        [HttpPut]
        [Route("/approval-queue/{approvalId}/approve")]
        public async Task<ActionResult> ApproveProduct(long approvalId)
        {
            // Note Here approvalId is considered as Product ID
            if (approvalId > 0)
            {
                await _productService.ApproveProductRequest(approvalId);
                return Ok();
            }
            else
            {
                return BadRequest($"Invalid product id {JsonSerializer.Serialize(approvalId)}");
            }
        }

        [HttpPut]
        [Route("/approval-queue/{approvalId}/reject")]
        public async Task<ActionResult> RejectProduct(long approvalId)
        {
            // Note Here approvalId is considered as Product ID
            if (approvalId > 0)
            {
                await _productService.RejectProductRequest(approvalId);
                return Ok();
            }
            else
            {
                return BadRequest($"Invalid product id {JsonSerializer.Serialize(approvalId)}");
            }
        }

    }
}
